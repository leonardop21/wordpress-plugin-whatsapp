<?php

/*
Plugin Name: Notifish
Description: Plugin para gerenciar notificações via API do Notifish.
Version: 2.0.0
Site: https://notifish.com
Author: Notifish
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// ============================================
// CONFIGURAÇÕES AGORA SÃO DINÂMICAS VIA ADMIN
// ============================================ 

class Notifish_Plugin {
    private $options;
    private $log_file;

    public function __construct() {
        // Define o arquivo de log
        $upload_dir = wp_upload_dir();
        $log_dir = WP_CONTENT_DIR . '/logs-notifish';
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }
        $this->log_file = $log_dir . '/notifish-' . date('Y-m-d') . '.log';
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'send_message_on_publish'));
        
        register_activation_hook(__FILE__, array($this, 'create_database'));
        
        // AJAX endpoints para QR Code
        add_action('wp_ajax_notifish_get_qrcode', array($this, 'ajax_get_qrcode'));
        add_action('wp_ajax_notifish_get_session_status', array($this, 'ajax_get_session_status'));
        add_action('wp_ajax_notifish_restart_session', array($this, 'ajax_restart_session'));
        add_action('wp_ajax_notifish_logout_session', array($this, 'ajax_logout_session'));
    }

    /**
     * Função helper para escrever logs
     */
    private function write_log($message, $data = null) {
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] $message";
        
        if ($data !== null) {
            $log_message .= "\n" . print_r($data, true);
        }
        
        $log_message .= "\n" . str_repeat('-', 80) . "\n";
        
        file_put_contents($this->log_file, $log_message, FILE_APPEND);
    }

    public function add_admin_menu() {
        // Menu principal
        add_menu_page(
            'Configurações do Notifish', 
            'Notifish', 
            'manage_options', 
            'notifish', 
            array($this, 'create_admin_page')
        );
    
        // Submenu
        add_submenu_page(
            'notifish',
            'Logs Enviadas', 
            'Notifish Logs', 
            'manage_options', 
            'notifish_requests', 
            array($this, 'requests_page')
        );
        
        // Submenu Status (apenas se usar v2)
        $options = get_option('notifish_options');
        $versao = isset($options['versao_notifish']) ? $options['versao_notifish'] : 'v1';
        if ($versao === 'v2') {
            add_submenu_page(
                'notifish',
                'WhatsApp Status',
                'WhatsApp Status',
                'manage_options',
                'notifish_qrcode',
                array($this, 'qrcode_page')
            );
        }
    }
    
    public function create_admin_page() {
        $this->options = get_option('notifish_options');
        require_once plugin_dir_path(__FILE__) . 'admin/config-page.php';
    }

    public function register_settings() {
        register_setting('notifish_group', 'notifish_options', array($this, 'sanitize'));
    }

    public function sanitize($input) {
        // Obtém as opções atuais do banco
        $current_options = get_option('notifish_options', array());
        
        $new_input = array();
        if (isset($input['api_url'])) {
            $new_input['api_url'] = sanitize_text_field($input['api_url']);
        }
        
        // Para API Key: só atualiza se o valor não for apenas asteriscos ou vazio
        if (isset($input['api_key'])) {
            $api_key_value = sanitize_text_field($input['api_key']);
            // Se o valor é vazio ou contém apenas asteriscos, mantém o valor atual do banco
            if (empty($api_key_value) || preg_match('/^[*]+$/', $api_key_value)) {
                // Mantém a chave existente do banco
                if (isset($current_options['api_key']) && !empty($current_options['api_key'])) {
                    $new_input['api_key'] = $current_options['api_key'];
                }
            } else {
                // Nova chave foi fornecida, atualiza
                $new_input['api_key'] = $api_key_value;
            }
        } else {
            // Se o campo não foi enviado, mantém o valor atual
            if (isset($current_options['api_key']) && !empty($current_options['api_key'])) {
                $new_input['api_key'] = $current_options['api_key'];
            }
        }
        
        if (isset($input['instance_uuid'])) {
            $new_input['instance_uuid'] = sanitize_text_field($input['instance_uuid']);
        }
        if (isset($input['default_whatsapp_enabled'])) {
            $new_input['default_whatsapp_enabled'] = sanitize_text_field($input['default_whatsapp_enabled']);
        }
        if (isset($input['versao_notifish'])) {
            $new_input['versao_notifish'] = sanitize_text_field($input['versao_notifish']);
        }
        return $new_input;
    }

    public function add_meta_box() {
        add_meta_box(
            'notifish_meta_box',
            'Notifish',
            array($this, 'meta_box_callback'),
            'post'
        );
    }

   public function meta_box_callback($post) {
        wp_nonce_field('notifish_meta_box', 'notifish_meta_box_nonce');
        $value = get_post_meta($post->ID, '_notifish_meta_value_key', true);
        
        // Verifica se o post já foi enviado (na tabela de requests)
        global $wpdb;
        $already_sent = false;
        if (!empty($post->ID)) {
            $count = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) FROM {$wpdb->prefix}notifish_requests 
                WHERE post_id = %d
            ", $post->ID));
            $already_sent = $count > 0;
        }
        
        // Verifica se é um post novo (sem ID ou auto-draft) ou se não tem valor salvo
        $is_new_post = empty($post->ID) || $post->post_status === 'auto-draft';
        $has_no_value = empty($value);
        
        $default_enabled = false;
        
        // Aplica configuração padrão apenas para posts novos ou posts sem valor salvo
        if ($is_new_post || $has_no_value) {
            $options = get_option('notifish_options');
            $default_enabled = isset($options['default_whatsapp_enabled']) && $options['default_whatsapp_enabled'] == '1';
        }
        
        // Determina se o checkbox deve estar marcado
        // Se já foi enviado, sempre desmarca independente da configuração padrão
        if ($already_sent) {
            $is_checked = false;
        } else {
            $is_checked = $default_enabled || ($value === '1' || $value === 1 || $value === true);
        }
        $checked_attr = $is_checked ? 'checked="checked"' : '';
        
        echo '<label for="notifish_send_notification_whatsapp">';
        echo 'Deseja compartilhar no WhatsApp?';
        echo '</label> ';
        echo '<input type="checkbox" id="notifish_send_notification_whatsapp" name="notifish_send_notification_whatsapp" value="1" ' . $checked_attr . ' />';
        
        // Exibe a mensagem se já foi enviado
        if ($already_sent) {
            echo '<p style="color: red;">A matéria já foi compartilhada no WhatsApp. Para reenviar, use o menu "Notifish Logs".</p>';
        }
    }



    public function send_message_on_publish($post_id) {
        $this->write_log("=== INÍCIO: send_message_on_publish ===", [
            'post_id' => $post_id,
            'POST_data' => $_POST,
            'has_nonce' => isset($_POST['notifish_meta_box_nonce']),
            'post_status' => get_post_status($post_id)
        ]);
        
        error_log("Notifish: send_message_on_publish chamado para post ID: " . $post_id);
        
        if (!isset($_POST['notifish_meta_box_nonce'])) {
            $this->write_log("ERRO: Nonce não encontrado, abortando envio");
            error_log("Notifish: Meta box nonce não encontrado para post $post_id");
            return;
        }
        if (!wp_verify_nonce($_POST['notifish_meta_box_nonce'], 'notifish_meta_box')) {
            error_log("Notifish: Nonce inválido para post $post_id");
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            error_log("Notifish: Autosave detectado, pulando post $post_id");
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            error_log("Notifish: Usuário sem permissão para post $post_id");
            return;
        }

        // Sempre salva a meta, independente do status do post
        $my_data = isset($_POST['notifish_send_notification_whatsapp']) ? sanitize_text_field($_POST['notifish_send_notification_whatsapp']) : '';
        
        $this->write_log("Valor do checkbox", [
            'checkbox_value_raw' => isset($_POST['notifish_send_notification_whatsapp']) ? $_POST['notifish_send_notification_whatsapp'] : 'NÃO DEFINIDO',
            'checkbox_value_sanitized' => $my_data,
            'checkbox_checked' => $my_data == '1'
        ]);
        
        error_log("Notifish: Salvando meta para post $post_id - Valor: '$my_data'");
        update_post_meta($post_id, '_notifish_meta_value_key', $my_data);

        $status = get_post_status($post_id);
        
        $this->write_log("Status do post", [
            'post_status' => $status,
            'is_published' => $status === 'publish',
            'checkbox_checked' => $my_data == '1',
            'will_send' => ($status === 'publish' && $my_data == '1')
        ]);
        
        error_log("Notifish: Status do post $post_id: $status");

        // Só envia a mensagem se o post estiver publicado
        if ($status === 'publish' && $my_data == '1') {
            $this->write_log("CONDIÇÕES ATENDIDAS: Post publicado e checkbox marcado - INICIANDO ENVIO");
            error_log("Notifish: Enviando mensagem para post publicado $post_id");
            $this->send_message($post_id);
        } else {
            $this->write_log("CONDIÇÕES NÃO ATENDIDAS: Post NÃO será enviado", [
                'reason' => $status !== 'publish' ? 'Post não está publicado' : 'Checkbox não está marcado',
                'status' => $status,
                'checkbox' => $my_data
            ]);
            error_log("Notifish: Post $post_id não será enviado - Status: $status, Meta: $my_data");
        }
    }

    private function send_message($post_id, $force = false) {
        error_log("Notifish: send_message chamado para post ID: " . $post_id . ", force: " . ($force ? 'true' : 'false'));
        
        global $wpdb;
        
        // Verifica se já foi enviado (só ignora se force = false)
        if (!$force) {
            $existing_request = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) FROM {$wpdb->prefix}notifish_requests 
                WHERE post_id = %d
            ", $post_id));
            
            if ($existing_request > 0) {
                error_log("Notifish: Post $post_id já foi enviado anteriormente, não reenviando. Use o menu 'Notifish Logs' para reenviar.");
                return;
            }
        }
        
        // Verifica qual versão usar baseado na configuração
        $this->options = get_option('notifish_options');
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        
        if ($versao === 'v2') {
            $this->send_message_v2($post_id);
        } else {
            $this->send_message_v1($post_id);
        }
        
        $this->write_log("=== FIM: send_message ===");
    }

    private function send_message_v1($post_id) {
        $this->write_log("=== INÍCIO: send_message_v1 ===", ['post_id' => $post_id]);
        
        error_log("Notifish: Usando API v1 para post ID: " . $post_id);
        
        global $wpdb;
        $this->options = get_option('notifish_options');
        
        // Verifica se as configurações estão definidas
        if (empty($this->options['api_url']) || empty($this->options['api_key']) || empty($this->options['instance_uuid'])) {
            $this->write_log("ERRO: Configurações não encontradas - ABORTANDO", [
                'api_url' => isset($this->options['api_url']) ? 'OK' : 'FALTANDO',
                'api_key' => isset($this->options['api_key']) ? 'OK' : 'FALTANDO',
                'instance_uuid' => isset($this->options['instance_uuid']) ? 'OK' : 'FALTANDO'
            ]);
            error_log("Notifish: Configurações não encontradas - API URL: " . (isset($this->options['api_url']) ? 'OK' : 'FALTANDO') . ", API Key: " . (isset($this->options['api_key']) ? 'OK' : 'FALTANDO') . ", Instance UUID: " . (isset($this->options['instance_uuid']) ? 'OK' : 'FALTANDO'));
            return;
        }
        
        $post_title = html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8');
        $post_url = get_permalink($post_id) . '?utm_source=whatsapp';
        
        $instance_uuid = $this->options['instance_uuid'];
        
        $this->write_log("Dados do post preparados", [
            'post_title' => $post_title,
            'post_url' => $post_url,
            'instance_uuid' => $instance_uuid
        ]);
        
        error_log("Notifish: Preparando envio - Título: $post_title, URL: $post_url, UUID: $instance_uuid");

        $body_data = array(
            'identifier' => $post_id . ' ' . bloginfo('name') . ' - Wordpress',
            'link' => true,
            'typing' => 'composing',
            'delay' => 1200,
            'message' => "*$post_title* \n\n $post_url",
        );
        
        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->options['api_key'],
            'Accept' => 'application/json'
        );

        $args = array(
            'body' => json_encode($body_data),
            'headers' => $headers
        );

        // Monta a URL da API do Notifish (já vem com /v1/ ou /v2/ do admin)
        $api_url_base = rtrim($this->options['api_url'], '/');
        $api_endpoint = $api_url_base . '/' . $instance_uuid . '/whatsapp/message/groups';
        
        $this->write_log("PREPARANDO ENVIO - v1", [
            'url_montada' => $api_endpoint,
            'headers' => $headers,
            'body' => $body_data,
            'body_json' => json_encode($body_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
        ]);
        
        $response = wp_remote_post($api_endpoint, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        $is_wp_error = is_wp_error($response);

        $this->write_log("RESPOSTA DA API - v1", [
            'status_code' => $status_code,
            'is_wp_error' => $is_wp_error,
            'wp_error_message' => $is_wp_error ? $response->get_error_message() : null,
            'response_headers' => $response_headers ? (array)$response_headers : null,
            'response_body' => $response_body,
            'response_body_decoded' => json_decode($response_body, true)
        ]);

        error_log("Notifish: Resposta da API - Status: $status_code, Body: $response_body");

        // Processa a resposta para exibir mensagem amigável
        $friendly_message = $this->get_friendly_message($status_code, $response_body);

        // Salvar request no banco de dados (sempre, independente do status code para manter histórico)
        $result = $wpdb->insert(
            "{$wpdb->prefix}notifish_requests",
            array(
                'post_id' => $post_id,
                'post_title' => $post_title,
                'phone_number' => 'Grupo',
                'status_code' => $status_code,
                'user_id' => get_current_user_id(),
                'user_name' => get_the_author_meta('display_name', get_current_user_id()),
                'response' => $friendly_message,
                'sent_at' => current_time('mysql')
            )
        );
        
        $this->write_log("Salvamento no banco de dados - v1", [
            'result' => $result,
            'wpdb_error' => $result ? null : $wpdb->last_error,
            'status_code' => $status_code,
            'saved_regardless_of_status' => true
        ]);
        
        if ($result) {
            error_log("Notifish: Request salvo no banco de dados com sucesso (Status: $status_code)");
        } else {
            error_log("Notifish: Erro ao salvar request no banco de dados: " . $wpdb->last_error);
        }
    }

    private function send_message_v2($post_id) {
        $this->write_log("=== INÍCIO: send_message_v2 ===", ['post_id' => $post_id]);
        
        error_log("Notifish: Usando API v2 para post ID: " . $post_id);
        
        global $wpdb;
        $this->options = get_option('notifish_options');
        
        // Obtém as configurações do admin
        $api_url = isset($this->options['api_url']) ? rtrim($this->options['api_url'], '/') : '';
        $api_key = isset($this->options['api_key']) ? $this->options['api_key'] : '';
        $instance_uuid = isset($this->options['instance_uuid']) ? $this->options['instance_uuid'] : '';
        
        $this->write_log("Configurações carregadas - v2", [
            'api_url' => $api_url,
            'has_api_key' => !empty($api_key),
            'instance_uuid' => $instance_uuid
        ]);
        
        // Verifica se as configurações estão definidas
        if (empty($api_url) || empty($api_key) || empty($instance_uuid)) {
            $this->write_log("ERRO: Configurações não encontradas - ABORTANDO", [
                'api_url' => $api_url ? 'OK' : 'FALTANDO',
                'api_key' => $api_key ? 'OK' : 'FALTANDO',
                'instance_uuid' => $instance_uuid ? 'OK' : 'FALTANDO'
            ]);
            error_log("Notifish: Configurações não encontradas - API URL: " . ($api_url ? 'OK' : 'FALTANDO') . ", API Key: " . ($api_key ? 'OK' : 'FALTANDO') . ", Instance UUID: " . ($instance_uuid ? 'OK' : 'FALTANDO'));
            return;
        }
        
        $post_title = html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8');
        $post_url = get_permalink($post_id) . '?utm_source=whatsapp';
        
        // Monta a mensagem com título e URL
        $message_text = "*$post_title* \n\n $post_url";

        $this->write_log("Dados do post preparados - v2", [
            'post_title' => $post_title,
            'post_url' => $post_url,
            'message_text' => $message_text
        ]);

        error_log("Notifish: Preparando envio - Título: $post_title, URL: $post_url, API URL: $api_url, Endpoint completo: " . $api_url . '/' . $instance_uuid . '/whatsapp/message/groups');

        // Monta a URL da API do Notifish (já vem com /v1/ ou /v2/ do admin)
        $api_endpoint = $api_url . '/' . $instance_uuid . '/whatsapp/message/groups';
        
        $body_data = array(
            'identifier' => $post_id . ' ' . get_bloginfo('name') . ' - Wordpress',
            'message' => $message_text,
            'linkPreview' => true,
            'delay' => 0
        );
        
        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
            'Accept' => 'application/json'
        );
        
        $args = array(
            'body' => json_encode($body_data, JSON_UNESCAPED_UNICODE),
            'headers' => $headers
        );

        $this->write_log("PREPARANDO ENVIO - v2", [
            'url_montada' => $api_endpoint,
            'headers' => $headers,
            'body' => $body_data,
            'body_json' => json_encode($body_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
        ]);

        $response = wp_remote_post($api_endpoint, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        $is_wp_error = is_wp_error($response);

        $this->write_log("RESPOSTA DA API - v2", [
            'status_code' => $status_code,
            'is_wp_error' => $is_wp_error,
            'wp_error_message' => $is_wp_error ? $response->get_error_message() : null,
            'response_headers' => $response_headers ? (array)$response_headers : null,
            'response_body' => $response_body,
            'response_body_decoded' => json_decode($response_body, true)
        ]);

        error_log("Notifish: Resposta da API v2 - Status: $status_code, Body: $response_body");

        // Processa a resposta para exibir mensagem amigável
        $friendly_message = $this->get_friendly_message($status_code, $response_body);
        
        // Salvar request no banco de dados (sempre, independente do status code para manter histórico)
        $result = $wpdb->insert(
            "{$wpdb->prefix}notifish_requests",
            array(
                'post_id' => $post_id,
                'post_title' => $post_title,
                'phone_number' => 'Grupo',
                'status_code' => $status_code,
                'user_id' => get_current_user_id(),
                'user_name' => get_the_author_meta('display_name', get_current_user_id()),
                'response' => $friendly_message,
                'sent_at' => current_time('mysql')
            )
        );
        
        $this->write_log("Salvamento no banco de dados - v2", [
            'result' => $result,
            'wpdb_error' => $result ? null : $wpdb->last_error,
            'status_code' => $status_code,
            'saved_regardless_of_status' => true
        ]);
        
        if ($result) {
            error_log("Notifish: Request salvo no banco de dados com sucesso (Status: $status_code)");
        } else {
            error_log("Notifish: Erro ao salvar request no banco de dados: " . $wpdb->last_error);
        }
        
        $this->write_log("=== FIM: send_message_v2 ===");
    }
    
    /**
     * Retorna mensagem amigável baseada no status code
     */
    private function get_friendly_message($status_code, $response_body) {
        switch ($status_code) {
            case 200:
            case 201:
                return 'Mensagem enviada';
            case 401:
                return 'Não autorizado';
            case 403:
                return 'Proibido';
            case 404:
                return 'Não encontrado';
            case 500:
                return 'Erro interno';
            default:
                // Para outros códigos, tenta extrair mensagem do JSON se disponível
                $data = json_decode($response_body, true);
                if (isset($data['message'])) {
                    return $data['message'];
                }
                return $response_body;
        }
    }

    public function create_database() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'notifish_requests';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            user_name varchar(255) NOT NULL,
            post_id bigint(20) NOT NULL,
            post_title text NOT NULL,
            phone_number varchar(255) NOT NULL,
            status_code int(3) NOT NULL,
            response text NOT NULL,
            sent_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id),
            INDEX idx_post_id (post_id),
            INDEX idx_phone_number (phone_number),
            INDEX idx_status_code (status_code),
            INDEX idx_user_id (user_id),
            INDEX idx_sent_at (sent_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function qrcode_page() {
        $this->options = get_option('notifish_options');
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        
        if ($versao !== 'v2') {
            echo '<div class="wrap"><h1>WhatsApp Status</h1>';
            echo '<div class="notice notice-error"><p>Esta funcionalidade está disponível apenas quando a versão está configurada como v2.</p></div>';
            echo '</div>';
            return;
        }
        
        $api_url = isset($this->options['api_url']) ? rtrim($this->options['api_url'], '/') . '/' : '';
        $api_key = isset($this->options['api_key']) ? $this->options['api_key'] : '';
        $instance_uuid = isset($this->options['instance_uuid']) ? $this->options['instance_uuid'] : '';
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        ?>
        <div class="wrap">
            <h1>WhatsApp Status</h1>
            <p>Escaneie o QR code abaixo com seu WhatsApp para conectar a sessão.</p>
            
            <div id="qrcode-container" style="text-align: center; margin: 30px 0; padding: 30px; background: #fff; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div id="qrcode-loading" style="padding: 40px;">
                    <span class="spinner is-active" style="float: none; margin: 0 auto; display: block;"></span>
                    <p style="margin-top: 15px; color: #666; font-size: 14px;">Carregando QR Code...</p>
                </div>
                <div id="qrcode-image" style="display: none;">
                    <img id="qrcode-img" src="" alt="QR Code" style="max-width: 400px; border: 2px solid #ddd; padding: 15px; background: white; border-radius: 8px;" />
                    <p style="margin-top: 15px; color: #666; font-size: 14px;">Escaneie este QR code com seu WhatsApp</p>
                </div>
                <div id="qrcode-error" style="display: none; color: #d63638; padding: 20px; background: #fef7f7; border: 1px solid #f5c2c7; border-radius: 4px;">
                    <p id="qrcode-error-message" style="margin: 0;"></p>
                </div>
            </div>
            
            <div id="session-status" style="margin: 20px 0; padding: 20px; background: #f8f9fa; border-left: 4px solid #2271b1; border-radius: 4px;">
                <h3 style="margin-top: 0;">Status da Sessão</h3>
                <p style="font-size: 16px; margin-bottom: 15px;">
                    <strong>Status:</strong> 
                    <span id="status-text" style="font-weight: 600; font-size: 16px;">Verificando...</span>
                </p>
                <div id="session-info" style="display: none; padding: 15px; background: #fff; border-radius: 4px; margin-top: 15px;">
                    <p style="margin: 5px 0;"><strong>Nome da Instância:</strong> <span id="instance-name"></span></p>
                    <p style="margin: 5px 0;"><strong>UUID da Instância:</strong> <span id="instance-uuid" style="font-family: monospace; font-size: 12px;"></span></p>
                    <p style="margin: 5px 0;"><strong>Versão WhatsApp:</strong> <span id="whatsapp-version"></span></p>
                </div>
            </div>
            
            <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button type="button" id="refresh-qrcode" class="button button-primary">
                    <span class="dashicons dashicons-update" style="vertical-align: middle; margin-right: 5px;"></span>
                    Atualizar QR Code
                </button>
                <button type="button" id="restart-session" class="button button-secondary">
                    <span class="dashicons dashicons-update" style="vertical-align: middle; margin-right: 5px;"></span>
                    Reiniciar Sessão
                </button>
                <button type="button" id="logout-session" class="button" style="background: #d63638; color: #fff; border-color: #d63638;">
                    <span class="dashicons dashicons-no-alt" style="vertical-align: middle; margin-right: 5px;"></span>
                    Desconectar
                </button>
            </div>
            
            <div id="action-message" style="margin-top: 15px; padding: 12px; border-radius: 4px; display: none;"></div>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            let qrcodeInterval;
            let statusInterval;
            
            function loadQRCode() {
                // Não carrega QR code se já estiver conectado
                const currentStatus = $('#status-text').text();
                const currentColor = $('#status-text').css('color');
                if (currentStatus.includes('Online') && currentColor === 'rgb(0, 163, 42)') {
                    return; // Já está conectado, não precisa carregar QR code
                }
                
                $('#qrcode-loading').show();
                $('#qrcode-image').hide();
                $('#qrcode-error').hide();
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'notifish_get_qrcode'
                    },
                    success: function(response) {
                        $('#qrcode-loading').hide();
                        
                        if (response.success) {
                            // Se está conectado, não mostra QR code
                            if (response.data && (response.data.connected || response.data.status === 'WORKING' || (response.data.instance && response.data.instance.state === 'open'))) {
                                $('#qrcode-image').hide();
                                $('#qrcode-error').hide();
                                return;
                            }
                            
                            if (response.data && response.data.data) {
                                // Mostra o QR code (pode vir como base64 direto ou com prefixo data:image)
                                let qrData = response.data.data;
                                if (qrData.startsWith('data:image')) {
                                    $('#qrcode-img').attr('src', qrData);
                                } else {
                                    $('#qrcode-img').attr('src', 'data:image/png;base64,' + qrData);
                                }
                                $('#qrcode-image').show();
                                
                                // Se tem erro mas ainda tem QR code, mostra o erro também
                                if (response.data.error) {
                                    $('#qrcode-error').show();
                                    $('#qrcode-error-message').text(response.data.error);
                                } else {
                                    $('#qrcode-error').hide();
                                }
                            } else if (response.data && response.data.error) {
                                // Erro sem QR code
                                $('#qrcode-image').hide();
                                $('#qrcode-error').show();
                                $('#qrcode-error-message').text(response.data.error);
                            } else {
                                $('#qrcode-error').show();
                                $('#qrcode-error-message').text('QR Code não disponível');
                            }
                        } else {
                            $('#qrcode-image').hide();
                            $('#qrcode-error').show();
                            $('#qrcode-error-message').text(response.data || 'Erro ao carregar QR Code');
                        }
                    },
                    error: function() {
                        $('#qrcode-loading').hide();
                        $('#qrcode-error').show();
                        $('#qrcode-error-message').text('Erro ao comunicar com o servidor');
                    }
                });
            }
            
            function checkSessionStatus() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'notifish_get_session_status'
                    },
                    success: function(response) {
                        if (response.success && response.data) {
                            const session = response.data;
                            
                            const state = session.state || session.status;
                            
                            if (state === 'open' || session.status === 'WORKING') {
                                // Sessão conectada - exibe "Online" em verde
                                $('#status-text').css({
                                    'color': '#00a32a',
                                    'font-weight': '600',
                                    'font-size': '18px'
                                }).text('● Online');
                                $('#session-info').show();
                                
                                // Exibe informações não confidenciais
                                $('#instance-name').text(session.instanceName || 'N/A');
                                $('#instance-uuid').text(session.instance_tenant_uuid || '<?php echo esc_js($instance_uuid); ?>');
                                
                                // Obtém a versão das opções do plugin
                                const versao = '<?php echo esc_js($versao); ?>';
                                $('#whatsapp-version').text(versao.toUpperCase());
                                
                                // Para TODOS os intervalos se estiver conectado
                                if (qrcodeInterval) {
                                    clearInterval(qrcodeInterval);
                                    qrcodeInterval = null;
                                }
                                if (statusInterval) {
                                    clearInterval(statusInterval);
                                    statusInterval = null;
                                }
                                
                                // Esconde QR code e erro quando conectado
                                $('#qrcode-image').hide();
                                $('#qrcode-error').hide();
                                $('#qrcode-loading').hide();
                                
                                return; // Para a função aqui, não continua verificando
                            } else if (state === 'close' || session.status === 'SCAN_QR_CODE') {
                                $('#status-text').css({
                                    'color': '#d63638',
                                    'font-weight': '600'
                                }).text('Aguardando leitura do QR Code');
                                
                                // Mostra informações básicas mesmo quando não conectado
                                if (session.instanceName || session.instance_tenant_uuid) {
                                    $('#session-info').show();
                                    $('#instance-name').text(session.instanceName || 'N/A');
                                    $('#instance-uuid').text(session.instance_tenant_uuid || '<?php echo esc_js($instance_uuid); ?>');
                                    const versao = '<?php echo esc_js($versao); ?>';
                                    $('#whatsapp-version').text(versao.toUpperCase());
                                } else {
                                    $('#session-info').hide();
                                }
                                
                                // Reinicia o intervalo de QR code se não estiver rodando
                                if (!qrcodeInterval) {
                                    qrcodeInterval = setInterval(loadQRCode, 10000);
                                }
                            } else {
                                $('#status-text').css({
                                    'color': '#d63638',
                                    'font-weight': '600'
                                }).text(session.status || 'Desconhecido');
                                $('#session-info').hide();
                            }
                        }
                    },
                    error: function() {
                        $('#status-text').css('color', 'red').text('Erro ao verificar status');
                    }
                });
            }
            
            // Verifica status inicialmente ANTES de iniciar intervalos
            checkSessionStatus();
            
            // Aguarda 1 segundo e verifica novamente para ter certeza do estado
            setTimeout(function() {
                checkSessionStatus();
                
                // Só inicia os intervalos se NÃO estiver conectado
                // Verifica se o status ainda não é "Online" (verde)
                const currentStatus = $('#status-text').text();
                const currentColor = $('#status-text').css('color');
                
                if (!currentStatus.includes('Online') || currentColor !== 'rgb(0, 163, 42)') {
                    // Não está conectado, inicia os intervalos
                    loadQRCode();
                    qrcodeInterval = setInterval(loadQRCode, 10000);
                    statusInterval = setInterval(checkSessionStatus, 5000);
                }
            }, 1000);
            
            // Botão de atualizar manualmente
            $('#refresh-qrcode').on('click', function() {
                const $btn = $(this);
                const originalText = $btn.html();
                $btn.prop('disabled', true).html('<span class="spinner is-active" style="float: none; margin: 0 5px;"></span>Atualizando...');
                
                // Limpa intervalos antes de verificar novamente
                if (qrcodeInterval) {
                    clearInterval(qrcodeInterval);
                    qrcodeInterval = null;
                }
                if (statusInterval) {
                    clearInterval(statusInterval);
                    statusInterval = null;
                }
                
                // Verifica status primeiro
                checkSessionStatus();
                
                // Aguarda um pouco e verifica novamente antes de iniciar intervalos
                setTimeout(function() {
                    const currentStatus = $('#status-text').text();
                    const currentColor = $('#status-text').css('color');
                    
                    if (!currentStatus.includes('Online') || currentColor !== 'rgb(0, 163, 42)') {
                        // Não está conectado, carrega QR code e inicia intervalos
                        loadQRCode();
                        qrcodeInterval = setInterval(loadQRCode, 10000);
                        statusInterval = setInterval(checkSessionStatus, 5000);
                    }
                    
                    $btn.prop('disabled', false).html(originalText);
                }, 1000);
            });
            
            // Botão de reiniciar sessão
            $('#restart-session').on('click', function() {
                const $btn = $(this);
                const originalText = $btn.html();
                $btn.prop('disabled', true).html('<span class="spinner is-active" style="float: none; margin: 0 5px;"></span>Reiniciando...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'notifish_restart_session'
                    },
                    success: function(response) {
                        $btn.prop('disabled', false).html(originalText);
                        
                        if (response.success) {
                            showMessage('Sessão reiniciada com sucesso!', 'success');
                            // Limpa intervalos e reinicia verificações
                            if (qrcodeInterval) {
                                clearInterval(qrcodeInterval);
                                qrcodeInterval = null;
                            }
                            if (statusInterval) {
                                clearInterval(statusInterval);
                                statusInterval = null;
                            }
                            
                            setTimeout(function() {
                                checkSessionStatus();
                                loadQRCode();
                                qrcodeInterval = setInterval(loadQRCode, 10000);
                                statusInterval = setInterval(checkSessionStatus, 5000);
                            }, 2000);
                        } else {
                            showMessage('Erro ao reiniciar: ' + (response.data || 'Erro desconhecido'), 'error');
                        }
                    },
                    error: function() {
                        $btn.prop('disabled', false).html(originalText);
                        showMessage('Erro ao comunicar com o servidor', 'error');
                    }
                });
            });
            
            // Botão de desconectar
            $('#logout-session').on('click', function() {
                if (!confirm('Tem certeza que deseja desconectar a sessão do WhatsApp?')) {
                    return;
                }
                
                const $btn = $(this);
                const originalText = $btn.html();
                $btn.prop('disabled', true).html('<span class="spinner is-active" style="float: none; margin: 0 5px;"></span>Desconectando...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'notifish_logout_session'
                    },
                    success: function(response) {
                        $btn.prop('disabled', false).html(originalText);
                        
                        if (response.success) {
                            showMessage('Sessão desconectada com sucesso!', 'success');
                            // Limpa intervalos e reinicia verificações
                            if (qrcodeInterval) {
                                clearInterval(qrcodeInterval);
                                qrcodeInterval = null;
                            }
                            if (statusInterval) {
                                clearInterval(statusInterval);
                                statusInterval = null;
                            }
                            
                            setTimeout(function() {
                                checkSessionStatus();
                                loadQRCode();
                                qrcodeInterval = setInterval(loadQRCode, 10000);
                                statusInterval = setInterval(checkSessionStatus, 5000);
                            }, 2000);
                        } else {
                            showMessage('Erro ao desconectar: ' + (response.data || 'Erro desconhecido'), 'error');
                        }
                    },
                    error: function() {
                        $btn.prop('disabled', false).html(originalText);
                        showMessage('Erro ao comunicar com o servidor', 'error');
                    }
                });
            });
            
            // Função para exibir mensagens
            function showMessage(message, type) {
                const $msg = $('#action-message');
                const bgColor = type === 'success' ? '#d4edda' : '#f8d7da';
                const borderColor = type === 'success' ? '#c3e6cb' : '#f5c6cb';
                const textColor = type === 'success' ? '#155724' : '#721c24';
                
                $msg.css({
                    'background': bgColor,
                    'border': '1px solid ' + borderColor,
                    'color': textColor,
                    'padding': '12px',
                    'border-radius': '4px'
                }).html(message).fadeIn();
                
                setTimeout(function() {
                    $msg.fadeOut();
                }, 5000);
            }
            
            // Limpa intervalos quando a página é fechada
            $(window).on('beforeunload', function() {
                if (qrcodeInterval) clearInterval(qrcodeInterval);
                if (statusInterval) clearInterval(statusInterval);
            });
        });
        </script>
        <?php
    }
    
    public function ajax_get_qrcode() {
        $this->options = get_option('notifish_options');
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        
        if ($versao !== 'v2') {
            wp_send_json_error('API v2 não está habilitada');
            return;
        }
        
        $api_url = isset($this->options['api_url']) ? rtrim($this->options['api_url'], '/') : '';
        $api_key = isset($this->options['api_key']) ? $this->options['api_key'] : '';
        $instance_uuid = isset($this->options['instance_uuid']) ? $this->options['instance_uuid'] : '';
        
        // Usa a API do Notifish para obter o QR code (já vem com /v1/ ou /v2/ do admin)
        $url = $api_url . '/' . $instance_uuid . '/whatsapp/login';
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ),
            'timeout' => 15
        );
        
        $response = wp_remote_post($url, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
            return;
        }
        
        $data = json_decode($response_body, true);
        
        if ($status_code == 200) {
            // A API v2 retorna o QR code no formato { "data": { "instance": {...}, "base64": "..." } }
            if (isset($data['data']['base64'])) {
                wp_send_json_success(array(
                    'data' => $data['data']['base64'],
                    'mimetype' => 'image/png'
                ));
            } elseif (isset($data['data']['instance']['state']) && $data['data']['instance']['state'] === 'open') {
                // Já está conectado - retorna sucesso sem erro e sem mensagem
                wp_send_json_success(array(
                    'status' => 'WORKING',
                    'connected' => true,
                    'state' => 'open'
                ));
            } else {
                wp_send_json_error('QR Code não disponível');
            }
        } else {
            $error_data = json_decode($response_body, true);
            if (isset($error_data['error'])) {
                wp_send_json_success(array(
                    'error' => $error_data['error'],
                    'status' => isset($error_data['status']) ? $error_data['status'] : null
                ));
            } else {
                wp_send_json_error('Erro ao obter QR Code: ' . $response_body);
            }
        }
    }
    
    public function ajax_get_session_status() {
        $this->options = get_option('notifish_options');
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        
        if ($versao !== 'v2') {
            wp_send_json_error('API v2 não está habilitada');
            return;
        }
        
        $api_url = isset($this->options['api_url']) ? rtrim($this->options['api_url'], '/') : '';
        $api_key = isset($this->options['api_key']) ? $this->options['api_key'] : '';
        $instance_uuid = isset($this->options['instance_uuid']) ? $this->options['instance_uuid'] : '';
        
        // Usa a API do Notifish para verificar o status (já vem com /v1/ ou /v2/ do admin)
        $url = $api_url . '/' . $instance_uuid . '/whatsapp/status';
        
        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Accept' => 'application/json'
            ),
            'timeout' => 15
        );
        
        $response = wp_remote_get($url, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
            return;
        }
        
        if ($status_code == 200) {
            $data = json_decode($response_body, true);
            
            // O Laravel retorna: { "instance": {...}, "base64": "..." } ou apenas { "instance": {...} }
            if (isset($data['instance'])) {
                $instance = $data['instance'];
                $state = isset($instance['state']) ? $instance['state'] : 'UNKNOWN';
                
                wp_send_json_success(array(
                    'status' => ($state === 'open') ? 'WORKING' : (($state === 'close') ? 'SCAN_QR_CODE' : 'UNKNOWN'),
                    'state' => $state,
                    'instanceName' => isset($instance['instanceName']) ? $instance['instanceName'] : '',
                    'instance_tenant_uuid' => isset($instance['instance_tenant_uuid']) ? $instance['instance_tenant_uuid'] : ''
                ));
                return;
            }
            
            // Formato com wrapper data
            if (isset($data['data']['instance'])) {
                $instance = $data['data']['instance'];
                $state = isset($instance['state']) ? $instance['state'] : 'UNKNOWN';
                
                wp_send_json_success(array(
                    'status' => ($state === 'open') ? 'WORKING' : (($state === 'close') ? 'SCAN_QR_CODE' : 'UNKNOWN'),
                    'state' => $state,
                    'instanceName' => isset($instance['instanceName']) ? $instance['instanceName'] : '',
                    'instance_tenant_uuid' => isset($instance['instance_tenant_uuid']) ? $instance['instance_tenant_uuid'] : ''
                ));
                return;
            }
            
            wp_send_json_error('Dados da sessão não encontrados');
        } else {
            $error_data = json_decode($response_body, true);
            if (isset($error_data['message'])) {
                wp_send_json_error($error_data['message']);
            } else {
                wp_send_json_error('Erro ao obter status: ' . $response_body);
            }
        }
    }

    public function requests_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'notifish_requests';
        
        if (isset($_POST['resend'])) {
            $id = intval($_POST['resend']);
            $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            if ($request) {
                $this->resend_message($request);
            }
        }
        
        
        // Consulta para obter os últimos 20 registros, ordenados por ID de forma decrescente
        $requests = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC LIMIT 20");
        
        echo '<div class="wrap"><h1>Notifish Logs</h1><h4>Listando às últimas 20</h4>';
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>ID</th><th>Post ID</th><th>Título</th><th>Telefone</th><th>Status</th><th>Resposta</th><th>Data</th><th>Ações</th></tr></thead><tbody>';
        foreach ($requests as $request) {
            echo '<tr>';
            echo '<td>' . $request->id . '</td>';
            echo '<td>' . $request->post_id . '</td>';
            echo '<td>' . $request->post_title . '</td>';
            echo '<td>' . $request->phone_number . '</td>';
            echo '<td>' . $request->status_code . '</td>';
            echo '<td>' . $request->response . '</td>';
            echo '<td>' . $request->sent_at . '</td>';
            echo '<td>';
            // if ($request->status_code != 200 && $request->status_code != 201) {
                echo '<form method="post"><button type="submit" name="resend" value="' . $request->id . '">Reenviar</button></form>';
            // }
            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    private function resend_message($request) {
        // Verifica qual versão usar baseado na configuração
        $this->options = get_option('notifish_options');
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        
        if ($versao === 'v2') {
            $this->resend_message_v2($request);
        } else {
            $this->resend_message_v1($request);
        }
    }

    private function resend_message_v1($request) {
        $this->write_log("=== INÍCIO: resend_message_notifish (v1) ===", [
            'request_id' => $request->id,
            'post_id' => $request->post_id
        ]);
        
        $this->options = get_option('notifish_options');
        
        if (empty($this->options['api_url']) || empty($this->options['api_key']) || empty($this->options['instance_uuid'])) {
            $this->write_log("ERRO: Configurações não encontradas - ABORTANDO REENVIO");
            return;
        }

        $post_title = html_entity_decode(get_the_title($request->post_id), ENT_QUOTES, 'UTF-8');
        $post_url = get_permalink($request->post_id) . '?utm_source=whatsapp';

        $this->write_log("Dados do post preparados para reenvio - v1", [
            'post_title' => $post_title,
            'post_url' => $post_url
        ]);

        $body_data = array(
            'identifier' => $request->post_id . ' ' . bloginfo('name') . ' - Wordpress resend',
            'link' => true,
            'typing' => 'composing',
            'delay' => 1200,
            'message' => "*$post_title* \n\n $post_url",
        );
        
        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->options['api_key'],
            'Accept' => 'application/json'
        );

        $args = array(
            'body' => json_encode($body_data),
            'headers' => $headers
        );

        // Monta a URL da API do Notifish (já vem com /v1/ ou /v2/ do admin)
        $api_url_base = rtrim($this->options['api_url'], '/');
        $api_endpoint = $api_url_base . '/' . $this->options['instance_uuid'] . '/whatsapp/message/groups';
        
        $this->write_log("PREPARANDO REENVIO - v1", [
            'url_montada' => $api_endpoint,
            'headers' => $headers,
            'body' => $body_data,
            'body_json' => json_encode($body_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
        ]);
        
        $response = wp_remote_post($api_endpoint, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        $is_wp_error = is_wp_error($response);

        $this->write_log("RESPOSTA DA API - REENVIO v1", [
            'status_code' => $status_code,
            'is_wp_error' => $is_wp_error,
            'wp_error_message' => $is_wp_error ? $response->get_error_message() : null,
            'response_headers' => $response_headers ? (array)$response_headers : null,
            'response_body' => $response_body,
            'response_body_decoded' => json_decode($response_body, true)
        ]);

        // Processa a resposta para exibir mensagem amigável
        $friendly_message = $this->get_friendly_message($status_code, $response_body);
        
        // Cria um NOVO registro no banco (não atualiza o existente) para manter histórico
        global $wpdb;
        $result = $wpdb->insert(
            "{$wpdb->prefix}notifish_requests",
            array(
                'post_id' => $request->post_id,
                'post_title' => $post_title,
                'phone_number' => 'Grupo',
                'status_code' => $status_code,
                'user_id' => get_current_user_id(),
                'user_name' => get_the_author_meta('display_name', get_current_user_id()),
                'response' => $friendly_message,
                'sent_at' => current_time('mysql')
            )
        );
        
        $this->write_log("NOVO REGISTRO CRIADO NO BANCO - REENVIO v1", [
            'result' => $result,
            'wpdb_error' => $result ? null : $wpdb->last_error,
            'status_code' => $status_code,
            'new_record_id' => $result ? $wpdb->insert_id : null
        ]);
        
        $this->write_log("=== FIM: resend_message_notifish (v1) ===");
    }

    private function resend_message_v2($request) {
        $this->write_log("=== INÍCIO: resend_message_v2 ===", [
            'request_id' => $request->id,
            'post_id' => $request->post_id
        ]);
        
        $this->options = get_option('notifish_options');
        
        // Obtém as configurações do admin
        $api_url = isset($this->options['api_url']) ? rtrim($this->options['api_url'], '/') : '';
        $api_key = isset($this->options['api_key']) ? $this->options['api_key'] : '';
        $instance_uuid = isset($this->options['instance_uuid']) ? $this->options['instance_uuid'] : '';
        
        if (empty($api_url) || empty($api_key) || empty($instance_uuid)) {
            $this->write_log("ERRO: Configurações não encontradas - ABORTANDO REENVIO");
            return;
        }

        $post_title = html_entity_decode(get_the_title($request->post_id), ENT_QUOTES, 'UTF-8');
        $post_url = get_permalink($request->post_id) . '?utm_source=whatsapp';
        
        // Monta a mensagem com título e URL
        $message_text = "*$post_title* \n\n $post_url";

        $this->write_log("Dados do post preparados para reenvio - v2", [
            'post_title' => $post_title,
            'post_url' => $post_url,
            'message_text' => $message_text
        ]);

        // Monta a URL da API do Notifish (já vem com /v1/ ou /v2/ do admin)
        $api_endpoint = $api_url . '/' . $instance_uuid . '/whatsapp/message/groups';

        $body_data = array(
            'identifier' => $request->post_id . ' ' . get_bloginfo('name') . ' - Wordpress resend',
            'message' => $message_text,
            'linkPreview' => true,
            'delay' => 0
        );
        
        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
            'Accept' => 'application/json'
        );

        $args = array(
            'body' => json_encode($body_data, JSON_UNESCAPED_UNICODE),
            'headers' => $headers
        );

        $this->write_log("PREPARANDO REENVIO - v2", [
            'url_montada' => $api_endpoint,
            'headers' => $headers,
            'body' => $body_data,
            'body_json' => json_encode($body_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
        ]);

        $response = wp_remote_post($api_endpoint, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        $is_wp_error = is_wp_error($response);

        $this->write_log("RESPOSTA DA API - REENVIO v2", [
            'status_code' => $status_code,
            'is_wp_error' => $is_wp_error,
            'wp_error_message' => $is_wp_error ? $response->get_error_message() : null,
            'response_headers' => $response_headers ? (array)$response_headers : null,
            'response_body' => $response_body,
            'response_body_decoded' => json_decode($response_body, true)
        ]);

        // Processa a resposta para exibir mensagem amigável
        $friendly_message = $this->get_friendly_message($status_code, $response_body);
        
        // Cria um NOVO registro no banco (não atualiza o existente) para manter histórico
        global $wpdb;
        $result = $wpdb->insert(
            "{$wpdb->prefix}notifish_requests",
            array(
                'post_id' => $request->post_id,
                'post_title' => $post_title,
                'phone_number' => 'Grupo',
                'status_code' => $status_code,
                'user_id' => get_current_user_id(),
                'user_name' => get_the_author_meta('display_name', get_current_user_id()),
                'response' => $friendly_message,
                'sent_at' => current_time('mysql')
            )
        );
        
        $this->write_log("NOVO REGISTRO CRIADO NO BANCO - REENVIO v2", [
            'result' => $result,
            'wpdb_error' => $result ? null : $wpdb->last_error,
            'status_code' => $status_code,
            'new_record_id' => $result ? $wpdb->insert_id : null
        ]);
        
        $this->write_log("=== FIM: resend_message_v2 ===");
    }
    
    public function ajax_restart_session() {
        $this->options = get_option('notifish_options');
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        
        if ($versao !== 'v2') {
            wp_send_json_error('API v2 não está habilitada');
            return;
        }
        
        $api_url = isset($this->options['api_url']) ? rtrim($this->options['api_url'], '/') : '';
        $api_key = isset($this->options['api_key']) ? $this->options['api_key'] : '';
        $instance_uuid = isset($this->options['instance_uuid']) ? $this->options['instance_uuid'] : '';
        
        if (empty($api_url) || empty($api_key) || empty($instance_uuid)) {
            wp_send_json_error('Configurações não encontradas');
            return;
        }
        
        // Usa a API do Notifish para reiniciar a sessão (GET /restart)
        $url = $api_url . '/' . $instance_uuid . '/whatsapp/restart';
        
        $args = array(
            'method' => 'GET',
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Accept' => 'application/json'
            ),
            'timeout' => 30
        );
        
        $response = wp_remote_request($url, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
            return;
        }
        
        if ($status_code == 200 || $status_code == 201) {
            $data = json_decode($response_body, true);
            if (isset($data['status']) && $data['status'] === 'success') {
                wp_send_json_success('Sessão reiniciada com sucesso');
            } else {
                wp_send_json_success('Sessão reiniciada');
            }
        } else {
            $error_data = json_decode($response_body, true);
            wp_send_json_error(isset($error_data['message']) ? $error_data['message'] : 'Erro ao reiniciar sessão');
        }
    }
    
    public function ajax_logout_session() {
        $this->options = get_option('notifish_options');
        $versao = isset($this->options['versao_notifish']) ? $this->options['versao_notifish'] : 'v1';
        
        if ($versao !== 'v2') {
            wp_send_json_error('API v2 não está habilitada');
            return;
        }
        
        $api_url = isset($this->options['api_url']) ? rtrim($this->options['api_url'], '/') : '';
        $api_key = isset($this->options['api_key']) ? $this->options['api_key'] : '';
        $instance_uuid = isset($this->options['instance_uuid']) ? $this->options['instance_uuid'] : '';
        
        if (empty($api_url) || empty($api_key) || empty($instance_uuid)) {
            wp_send_json_error('Configurações não encontradas');
            return;
        }
        
        // Usa a API do Notifish para desconectar a sessão (POST /logout)
        $url = $api_url . '/' . $instance_uuid . '/whatsapp/logout';
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ),
            'timeout' => 30
        );
        
        $response = wp_remote_request($url, $args);
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
            return;
        }
        
        if ($status_code == 200 || $status_code == 201) {
            $data = json_decode($response_body, true);
            if (isset($data['status']) && $data['status'] === 'success') {
                wp_send_json_success('Sessão desconectada com sucesso');
            } else {
                wp_send_json_success('Sessão desconectada');
            }
        } else {
            $error_data = json_decode($response_body, true);
            wp_send_json_error(isset($error_data['message']) ? $error_data['message'] : 'Erro ao desconectar sessão');
        }
    }
}

if (is_admin()) {
    $notifish_plugin = new Notifish_Plugin();
}